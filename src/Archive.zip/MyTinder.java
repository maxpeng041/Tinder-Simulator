import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class MyTinder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tinder tinder = new Tinder();
		
		JSONParser parser = new JSONParser();	
		try {
			Object obj = parser.parse(new FileReader("users.json"));
			//System.out.println("File exists.");
			JSONArray jsonArray = (JSONArray) obj;
            
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                //System.out.println(jsonObject);
                
                double longitude;
                double latitude;
                long id = (long) jsonObject.get("id");
                String first_name = (String) jsonObject.get("first_name");
                String last_name = (String) jsonObject.get("last_name");
                String email = (String) jsonObject.get("email");
                String gender = (String) jsonObject.get("gender");
                String interesed = (String) jsonObject.get("interesed");
                
                //find longitude from json file
                //if longitude is not double, convert string or long to double
                try{
                	longitude = (double) jsonObject.get("longitude");
                }
                catch(ClassCastException e){
                	try{
                		String longitudeString = (String) jsonObject.get("longitude");
                    	longitude = Double.parseDouble(longitudeString);
                	}
                	catch(ClassCastException e1){
                		long longitudeLong = (long) jsonObject.get("longitude");
                		longitude = (double) longitudeLong;
                	}
                }
                
                try{
                	latitude = (double) jsonObject.get("latitude");
                }
                catch(ClassCastException e){
                	try{
                		String latitudeString = (String) jsonObject.get("latitude");
                		latitude = Double.parseDouble(latitudeString);
                	}
                	catch(ClassCastException e1){
                		long latitudeLong = (long) jsonObject.get("latitude");
                		latitude = (double) latitudeLong;
                	}
                }
                
                tinder.addUser(new User(i));
                tinder.setID(i, id);
                tinder.getUser(id).firstName = first_name;
                tinder.getUser(id).lastName = last_name;
                tinder.getUser(id).email = email;
                tinder.getUser(id).gender = gender;
                tinder.getUser(id).interestedGender = interesed;
				tinder.getUser(id).longitude = longitude;
                tinder.getUser(id).latitude = latitude;
                
                //System.out.println(first_name + ": " + tinder.getUser(id).id);
            }
            
            
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(int i=0; i<tinder.users.size(); i++){
			for(int j=i+1; j<tinder.users.size(); j++){
				double lat1 = Math.toRadians(tinder.getUser(i+1).latitude);
				double lat2 = Math.toRadians(tinder.getUser(j+1).latitude);
				double latDif = Math.toRadians(tinder.getUser(j+1).latitude - tinder.getUser(i+1).latitude);
				double lonDif = Math.toRadians(tinder.getUser(j+1).longitude - tinder.getUser(i+1).longitude);
				double a = Math.sin(latDif/2)*Math.sin(latDif/2)+Math.cos(lat1)*Math.cos(lat2)*Math.sin(lonDif/2)*Math.sin(lonDif/2);
				double c = 2*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
				double distance = 6371*c/1.609344;
				if(distance<10){
					tinder.addLink(tinder.getUser(i+1), tinder.getUser(j+1));
					System.out.println("user" + tinder.getUser(i+1).id+" with longitude "+ tinder.getUser(i+1).longitude+", latitude "+tinder.getUser(i+1).latitude);
					System.out.println("user" + tinder.getUser(j+1).id+" with longitude "+ tinder.getUser(j+1).longitude+", latitude "+tinder.getUser(j+1).latitude);
					System.out.println("distance: " + distance);
					System.out.println();
				}
			}
		}
	}
}
