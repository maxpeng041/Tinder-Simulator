Name: Max Peng

I did all the work without collaborating with anyone. I got my help from the links on the homework description and internet for syntax.

I followed the graph code on moodle to make User.java, Link.java, Tinder.java, and MyTinder.java. The most tricky part was MyTinder because 1) I have to decode the json file and 2) not all the latitudes and longitudes are double, so I have to use try catch method to convert all the long and string types into double.